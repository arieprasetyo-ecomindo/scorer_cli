# Pomodoro Timer

## Purpose

Defines the server-authoritative Pomodoro timer state machine: phases (idle, focus, short-break, long-break), transitions between them, hardcoded durations, and the single global timer shared by all clients. Enforces the purist stance (no pause; stop = abandon).

## Requirements

### Requirement: Server-authoritative timer state

The system SHALL hold the authoritative timer state in memory within the FastAPI process. The state SHALL include the current phase (`idle`, `focus`, `short-break`, `long-break`), the timestamp at which the current phase started, and the number of completed pomodori in the current cycle (0–3, resetting to 0 after the 4th). The browser SHALL NOT hold or compute remaining time; it SHALL only display values received from the server.

#### Scenario: Initial state

- **WHEN** the server starts
- **THEN** the timer state is `idle`, the completed count is 0, and no phase start timestamp is set

#### Scenario: Remaining time is computed on read

- **WHEN** the timer is in `focus` phase and a client requests the timer state
- **THEN** the system computes remaining time as `25 minutes - (now - started_at)` and returns the current phase and remaining time

### Requirement: Start a focus interval

The system SHALL provide a Start control that transitions the timer from `idle` to `focus`. Starting a focus interval SHALL record the current timestamp as `started_at` and SHALL NOT increment the completed count. The Start control SHALL only be available when the phase is `idle`.

#### Scenario: Start from idle

- **WHEN** the phase is `idle` and the user activates Start
- **THEN** the phase becomes `focus`, `started_at` is set to the current time, and the completed count is unchanged

#### Scenario: Start is unavailable during focus

- **WHEN** the phase is `focus`
- **THEN** no Start control is rendered

#### Scenario: Start is unavailable during a break

- **WHEN** the phase is `short-break` or `long-break`
- **THEN** no Start control is rendered

### Requirement: Stop abandons the current pomodoro (purist stance)

The system SHALL provide a Stop control that is available only during the `focus` phase. Activating Stop SHALL abandon the current pomodoro: the phase returns to `idle`, the `started_at` timestamp is cleared, and the completed count is NOT incremented. The system SHALL NOT provide any pause or resume capability.

#### Scenario: Stop during focus abandons the pomodoro

- **WHEN** the phase is `focus` and the user activates Stop
- **THEN** the phase becomes `idle`, `started_at` is cleared, and the completed count is unchanged

#### Scenario: Stop is unavailable during a break

- **WHEN** the phase is `short-break` or `long-break`
- **THEN** no Stop control is rendered (breaks run to completion)

#### Scenario: No pause capability exists

- **WHEN** the phase is `focus`
- **THEN** the only available control is Stop; there is no Pause or Resume control

### Requirement: Focus interval elapses into a break

When a focus interval's remaining time reaches zero, the system SHALL transition to a break phase automatically. The break type SHALL be determined by the completed count: if the just-completed pomodoro was the 4th in the cycle (completed count was 3 before the focus started, becoming 4), the system SHALL transition to `long-break`; otherwise it SHALL transition to `short-break`. Upon transitioning, the system SHALL increment the completed count and set `started_at` to the current time.

#### Scenario: First pomodoro completes → short break

- **WHEN** the phase is `focus`, the completed count is 0, and remaining time reaches zero
- **THEN** the phase becomes `short-break`, the completed count becomes 1, and `started_at` is set to the current time

#### Scenario: Fourth pomodoro completes → long break

- **WHEN** the phase is `focus`, the completed count is 3, and remaining time reaches zero
- **THEN** the phase becomes `long-break`, the completed count becomes 4, and `started_at` is set to the current time

### Requirement: Break elapses into idle (no auto-chain)

When a break's remaining time reaches zero, the system SHALL transition to `idle`. If the just-completed break was a `long-break` (completed count was 4), the system SHALL reset the completed count to 0. The system SHALL NOT automatically start the next focus interval; the user MUST activate Start to begin the next pomodoro.

#### Scenario: Short break ends → idle, cycle continues

- **WHEN** the phase is `short-break` and remaining time reaches zero
- **THEN** the phase becomes `idle`, `started_at` is cleared, and the completed count is unchanged

#### Scenario: Long break ends → idle, cycle resets

- **WHEN** the phase is `long-break` and remaining time reaches zero
- **THEN** the phase becomes `idle`, `started_at` is cleared, and the completed count resets to 0

### Requirement: Hardcoded durations

The system SHALL use fixed durations: focus = 25 minutes, short break = 5 minutes, long break = 15 minutes. The system SHALL NOT provide any mechanism to configure these durations.

#### Scenario: Focus duration is 25 minutes

- **WHEN** a focus interval starts
- **THEN** its duration is exactly 25 minutes (1500 seconds)

#### Scenario: Short break duration is 5 minutes

- **WHEN** a short break starts
- **THEN** its duration is exactly 5 minutes (300 seconds)

#### Scenario: Long break duration is 15 minutes

- **WHEN** a long break starts
- **THEN** its duration is exactly 15 minutes (900 seconds)

### Requirement: Single global timer (no session isolation)

The system SHALL maintain exactly one timer instance shared across all clients. The system SHALL NOT use session cookies, per-browser state, or any form of client isolation. All clients viewing the app SHALL observe the same timer state.

#### Scenario: Two browsers see the same timer

- **WHEN** two browser tabs are open and one client starts a focus interval
- **THEN** both tabs display the same phase and remaining time on their next poll
