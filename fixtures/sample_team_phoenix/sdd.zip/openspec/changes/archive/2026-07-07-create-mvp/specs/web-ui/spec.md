## ADDED Requirements

### Requirement: Single-page interface with htmx fragment swaps

The system SHALL serve a single HTML page at `GET /` containing the Pomodoro timer interface. The timer display SHALL be an htmx-polled fragment: a container element with `hx-get="/timer"` and `hx-trigger="every 1s"` that swaps its content with the server-rendered fragment on every poll. The page SHALL NOT reload in response to timer state changes.

#### Scenario: Page loads with polling container

- **WHEN** a client requests `GET /`
- **THEN** the response is a full HTML page containing a timer container configured to poll `/timer` every second and swap its content

#### Scenario: Timer updates without page reload

- **WHEN** the timer is in `focus` phase and one second elapses
- **THEN** the browser issues `GET /timer`, receives a fragment, and swaps the timer container's content without reloading the page

### Requirement: Phase-specific rendered fragments

The `GET /timer` endpoint SHALL return different HTML depending on the current phase. The idle fragment SHALL render the Start control and the current completed count. The focus fragment SHALL render the countdown, the current pomodoro number, and the Stop control. The break fragment SHALL render the break countdown and break type (short or long) and SHALL NOT render a Stop control.

#### Scenario: Idle fragment

- **WHEN** the phase is `idle` and `GET /timer` is requested
- **THEN** the response contains a Start control and the completed count, and does not contain a Stop control

#### Scenario: Focus fragment

- **WHEN** the phase is `focus` and `GET /timer` is requested
- **THEN** the response contains the remaining countdown, the current pomodoro number, and a Stop control

#### Scenario: Break fragment

- **WHEN** the phase is `short-break` or `long-break` and `GET /timer` is requested
- **THEN** the response contains the remaining countdown and the break type, and does not contain a Stop control

### Requirement: Start and Stop controls submit via htmx

The Start control SHALL issue `POST /start` and the Stop control SHALL issue `POST /stop`, each via htmx. Both endpoints SHALL return the updated timer fragment so the UI reflects the new phase immediately without a separate poll round-trip.

#### Scenario: Start control triggers focus

- **WHEN** the phase is `idle` and the user activates the Start control
- **THEN** the browser issues `POST /start`, the server transitions to `focus`, and the response is the focus fragment which is swapped into the timer container

#### Scenario: Stop control abandons focus

- **WHEN** the phase is `focus` and the user activates the Stop control
- **THEN** the browser issues `POST /stop`, the server transitions to `idle`, and the response is the idle fragment which is swapped into the timer container

### Requirement: Alpine.js limited to non-timer polish

Alpine.js MAY be used for minor UI polish such as button hover states or visual transitions. Alpine.js SHALL NOT hold, compute, or display timer state; all timer values SHALL originate from server-rendered fragments.

#### Scenario: Timer value is never client-computed

- **WHEN** the timer fragment is rendered
- **THEN** the displayed remaining time is taken directly from server-rendered HTML, not computed by Alpine.js

### Requirement: Minimal styling via CSS

The interface SHALL be styled with CSS to present a clean, readable timer display. The styling SHALL make the current phase, countdown, and controls clearly visible. No CSS framework is required.

#### Scenario: Timer is readable

- **WHEN** the page is rendered in a browser
- **THEN** the countdown, phase, and controls are visually clear and legible
