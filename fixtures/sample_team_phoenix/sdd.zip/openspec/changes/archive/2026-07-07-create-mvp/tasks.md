## 1. Project setup

- [x] 1.1 Create `app/` package directory with `__init__.py`
- [x] 1.2 Add `pyproject.toml` (or `requirements.txt`) with `fastapi`, `uvicorn`, and `jinja2` dependencies
- [x] 1.3 Install dependencies via `uv pip install -r requirements.txt` inside the activated `.venv`

## 2. Timer state module

- [x] 2.1 Create `app/timer.py` with an in-memory singleton holding `phase`, `started_at`, and `completed_count`
- [x] 2.2 Implement `start_focus()` — transitions `idle` → `focus`, sets `started_at`, leaves `completed_count` unchanged
- [x] 2.3 Implement `stop_focus()` — transitions `focus` → `idle`, clears `started_at`, does NOT increment `completed_count`
- [x] 2.4 Implement `tick()` — called on each read; when remaining time reaches zero, transitions `focus` → `short-break` or `long-break` (long if `completed_count` was 3, becoming 4), and transitions `break` → `idle` (resetting count to 0 after a long break)
- [x] 2.5 Implement `get_state()` — returns current phase, remaining seconds, completed count, and pomodoro number, computing remaining time from `started_at` on read

## 3. FastAPI routes

- [x] 3.1 Create `app/main.py` with the FastAPI app instance and Jinja2 template configuration
- [x] 3.2 Implement `GET /` — renders the full page `index.html` with the polling container
- [x] 3.3 Implement `GET /timer` — calls `tick()` then renders the phase-specific fragment (`_idle.html`, `_focus.html`, or `_break.html`)
- [x] 3.4 Implement `POST /start` — calls `start_focus()` and returns the focus fragment
- [x] 3.5 Implement `POST /stop` — calls `stop_focus()` and returns the idle fragment

## 4. Templates

- [x] 4.1 Create `app/templates/index.html` — full page with htmx-included script, a `#timer` container with `hx-get="/timer" hx-trigger="every 1s" hx-swap="innerHTML"`, and a link to CSS
- [x] 4.2 Create `app/templates/_idle.html` — shows Start button (`hx-post="/start"`) and completed count
- [x] 4.3 Create `app/templates/_focus.html` — shows countdown, pomodoro number, and Stop button (`hx-post="/stop"`)
- [x] 4.4 Create `app/templates/_break.html` — shows countdown and break type (short/long), no Stop control

## 5. Styling

- [x] 5.1 Create `app/static/styles.css` with clean, readable styling for the timer display, phase label, countdown, and controls
- [x] 5.2 Mount the static directory in FastAPI and link the stylesheet from `index.html`

## 6. Alpine.js polish (minimal)

- [x] 6.1 Include Alpine.js via CDN script in `index.html`
- [x] 6.2 Add minor Alpine.js polish (e.g., button hover/active states) without touching timer state

## 7. Verification

- [x] 7.1 Run `uv run uvicorn app.main:app --reload` and confirm the server starts without errors
- [x] 7.2 Open the app in a browser and verify: Start begins a 25:00 focus countdown, Stop returns to idle, the countdown ticks down via polling
- [x] 7.3 Verify phase transitions: focus elapses → break fragment swaps in; break elapses → idle fragment swaps in; 4th focus → long break; long break ends → count resets to 0
- [x] 7.4 Verify no pause/resume control exists anywhere in the UI
