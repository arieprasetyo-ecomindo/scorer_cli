## Why

The repository is a greenfield demo of AI-enabled, token-optimized software development. There is no application code yet — only docs and OpenSpec scaffolding. We need a minimal, working Pomodoro web app to serve as the demo's deliverable and to exercise the full SDD workflow (propose → apply → archive) end-to-end.

## What Changes

- Introduce a FastAPI web application serving a single-page Pomodoro timer.
- Implement a **server-authoritative** timer: the FastAPI process holds the timer state in memory and is the single source of truth for phase and remaining time.
- Implement the **purist** Pomodoro stance: no pause. A pomodoro is indivisible — stopping abandons the current pomodoro and returns to idle.
- Render phase transitions (idle → focus → break → idle) via **htmx** fragment swaps, with no full page reloads. The browser polls a `/timer` endpoint every second to receive the current phase and remaining time.
- Cycle through 4 pomodori: focus 1–3 are followed by a short break; the 4th focus is followed by a long break, after which the cycle counter resets to 0.
- Hardcoded durations: focus = 25 min, short break = 5 min, long break = 15 min.
- Provide Start and Stop controls. No pause, no resume, no task label, no sound, no configuration, no persistence.
- Use Alpine.js minimally for button-state polish only; the timer itself is never driven by client-side logic.

## Capabilities

### New Capabilities

- `pomodoro-timer`: Server-authoritative timer that tracks the current phase (idle / focus / break), the remaining time, and the pomodoro cycle count. Enforces the purist stance (no pause; stop = abandon). Exposes the phase transitions and cycle logic (4th pomodoro → long break → reset).
- `web-ui`: htmx-driven single-page interface that polls the server for timer state and renders phase-appropriate views (idle, focus, break) via fragment swaps. Provides Start and Stop controls. Uses Alpine.js only for non-timer UX polish.

### Modified Capabilities

<!-- None — this is a greenfield project with no existing specs. -->

## Impact

- **New code**: `app/` package — FastAPI application, in-memory timer state, routes, and htmx-rendered templates.
- **Dependencies**: `fastapi`, `uvicorn`, `jinja2` (template rendering). No database, no external services.
- **APIs**: Four HTTP routes — `GET /` (full page), `GET /timer` (polled fragment), `POST /start`, `POST /stop`.
- **State**: A single in-memory, process-wide timer singleton. State is lost on server restart; this is acceptable for the demo.
- **No persistence layer**: No database, no session store, no cookies. The timer is shared globally across all clients (acceptable for a single-user local demo).
- **No existing code affected**: Greenfield; nothing to migrate or refactor.
