## Context

Greenfield repository: no application code exists yet. The project is a demo of AI-enabled, token-optimized software development. The tech stack is fixed by `AGENTS.md`: FastAPI (web service), htmx (backend-driven interactivity), Alpine.js (UX polish), CSS (styling). No data persistence of any kind is required or desired.

The Pomodoro Technique (see `docs/Pomodoro_Technique.md`) defines a focus/break cycle: 25-minute focus intervals separated by short breaks, with a long break after every 4th pomodoro. The technique emphasizes that a pomodoro is *indivisible* — interruptions mean recording and postponing, not pausing.

Key product decisions (from explore mode):
- **Server-authoritative timer**: FastAPI holds timer state in memory; the browser polls for display only.
- **Purist stance**: no pause. Stop = abandon the current pomodoro and return to idle.
- **MVP scope only**: hardcoded durations, no task label, no sound, no config, no persistence.
- **htmx renders phase transitions** via fragment swaps; no full page reloads.

## Goals / Non-Goals

**Goals:**
- A single FastAPI process holds the authoritative timer state in memory.
- The browser displays the timer by polling a `/timer` endpoint every second; htmx swaps the rendered fragment into the page.
- Phase transitions (idle → focus → break → idle) are driven entirely by server state; the client never computes remaining time.
- The purist stance is enforced: there is no pause/resume. Stop abandons the current pomodoro.
- The cycle counter advances 1→2→3→4; the 4th focus is followed by a long break, after which the counter resets to 0.
- Hardcoded durations: focus = 25 min, short break = 5 min, long break = 15 min.
- Minimal, clean UI with Start and Stop controls.

**Non-Goals:**
- No data persistence (no database, no session cookies, no localStorage).
- No pause or resume.
- No task label / "what am I working on?" input.
- No configurable durations.
- No sound or browser notifications.
- No multi-user or per-browser isolation — a single global timer is shared by all clients (acceptable for a local single-user demo).
- No disconnect detection / hardline abandonment on browser close.

## Decisions

### Decision 1: Server-authoritative timer via in-memory singleton

**Choice:** A module-level singleton object in the FastAPI process holds `{ phase, started_at, completed_count }`. Remaining time is computed on each request as `duration - (now - started_at)`.

**Rationale:** The user explicitly chose Option A (server-authoritative) over a client-side Alpine.js timer. This makes the server the single source of truth and aligns with the "htmx for interactivity" stack convention.

**Alternatives considered:**
- *Client-side Alpine.js timer*: rejected by user. Would lose state on refresh and contradict the server-authoritative decision.
- *Background task / asyncio loop ticking the timer*: unnecessary complexity. Computing remaining time on read is simpler and avoids race conditions from a mutating background task.

### Decision 2: Polling at 1s via `hx-trigger="every 1s"`

**Choice:** The timer fragment container uses `hx-get="/timer" hx-trigger="every 1s"` to poll the server every second and swap the rendered fragment.

**Rationale:** Dead simple, fully htmx-native, no extensions required. For a single-user local demo, 1 req/sec is negligible. SSE would add wiring (extension + event stream) for no real benefit at this scale.

**Alternatives considered:**
- *SSE via `hx-sse`*: more correct at scale, but over-engineered for a local demo. Rejected.
- *WebSockets*: same reasoning. Rejected.

### Decision 3: Purist stance — no pause, Stop = abandon

**Choice:** There is no `PAUSED` state in the state machine. The only controls are Start (idle → focus) and Stop (focus → idle, abandoning the pomodoro). Breaks cannot be stopped early — they run to completion and return to idle.

**Rationale:** Faithful to the technique's indivisibility rule. Also simplifies the state machine (no pause/resume edge cases, no "tainted pomodoro" tracking).

**Alternatives considered:**
- *Pragmatic pause with taint marker*: more complex, dilutes the purist stance the user chose. Rejected.
- *Standard app pause/resume*: contradicts the user's explicit decision. Rejected.

### Decision 4: Single global timer, no session isolation

**Choice:** One in-memory timer singleton shared by all clients. No session cookies, no per-browser state.

**Rationale:** The demo runs locally on one machine. Adding session management would add code with no demo value. The user accepted this in explore mode.

**Alternatives considered:**
- *Per-browser timer keyed by session cookie*: more correct, but unnecessary for the demo. Rejected.

### Decision 5: Breaks run to completion; focus requires explicit Start

**Choice:** When a focus interval elapses, the server transitions to the appropriate break (short or long) automatically. When a break elapses, the server transitions to idle — it does *not* auto-start the next focus. The user must press Start to begin the next pomodoro.

**Rationale:** Matches the technique's Step 5 ("go back to Step 2: set the timer") and the purist commitment that each pomodoro is a deliberate act. Auto-chaining would undermine that.

**Alternatives considered:**
- *Auto-chain focus after break*: more "app-like" but contradicts the purist stance. Rejected.

### Decision 6: htmx renders phase-specific fragments

**Choice:** The `/timer` endpoint returns different HTML depending on the current phase:
- `idle`: shows the Start button and current cycle count.
- `focus`: shows the countdown, the current pomodoro number, and the Stop button.
- `break`: shows the break countdown and break type (short/long); no Stop button.

The outer container polls every second, so phase transitions appear as seamless fragment swaps with no page reload.

**Rationale:** This is the canonical htmx pattern and directly fulfills the user's requirement to "use htmx to render a break content without page reload."

### Decision 7: Alpine.js limited to non-timer UX polish

**Choice:** Alpine.js is used only for minor UI polish (e.g., button hover states, visual transitions). It never holds or computes timer state.

**Rationale:** The user decided the timer is server-authoritative. Letting Alpine.js touch timer state would create a second source of truth and contradict the decision.

## Risks / Trade-offs

- **[State lost on server restart]** → Accepted. The demo explicitly requires no persistence. Documented in the proposal.
- **[Single global timer shared across browsers]** → Accepted for the local single-user demo. If two browsers open the app, they'll see the same timer. Documented as a non-goal.
- **[Polling at 1s causes 1 request/sec]** → Acceptable for a local demo. Would need SSE/WebSockets at scale, but that's out of scope.
- **[No disconnect detection]** → If the browser closes mid-focus, the server timer keeps running and the pomodoro will complete on its own. The user chose the lenient stance in explore mode. Accepted.
- **[Clock drift / latency]** → Remaining time is computed on read from `started_at`, so there's no drift in the source of truth. Display latency is bounded by the 1s poll interval. Acceptable.
- **[Purist stance may surprise users expecting pause]** → This is a deliberate product decision, not a bug. The UI should make the "Stop = abandon" semantics clear (e.g., button label or tooltip).
