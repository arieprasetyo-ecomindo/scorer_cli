"""Server-authoritative in-memory Pomodoro timer (purist stance, no persistence)."""

from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional


# Hardcoded durations (seconds).
FOCUS_SECONDS = 25 * 60
SHORT_BREAK_SECONDS = 5 * 60
LONG_BREAK_SECONDS = 15 * 60


class Phase(str, Enum):
    IDLE = "idle"
    FOCUS = "focus"
    SHORT_BREAK = "short-break"
    LONG_BREAK = "long-break"


# Break type label for UI rendering.
BREAK_LABELS = {
    Phase.SHORT_BREAK: "Short Break",
    Phase.LONG_BREAK: "Long Break",
}


@dataclass
class TimerState:
    """Snapshot of the timer returned by get_state()."""

    phase: Phase
    remaining_seconds: int
    completed_count: int
    pomodoro_number: int
    break_label: str


class PomodoroTimer:
    """Single global, in-memory timer. No persistence, no pause.

    State machine:
        idle --start--> focus --elapse--> break --elapse--> idle
                                  ^
                                  +-- long break after 4th pomodoro, then count resets
        focus --stop--> idle (abandon; count NOT incremented)
    """

    def __init__(self) -> None:
        self._phase: Phase = Phase.IDLE
        self._started_at: Optional[float] = None
        self._completed_count: int = 0  # pomodori completed in current cycle (0..4)

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def start_focus(self) -> None:
        """idle -> focus. Sets started_at; does NOT change completed_count."""
        if self._phase != Phase.IDLE:
            return  # Start is only valid from idle; ignore otherwise.
        self._phase = Phase.FOCUS
        self._started_at = time.monotonic()

    def stop_focus(self) -> None:
        """focus -> idle. Abandons the pomodoro; count NOT incremented."""
        if self._phase != Phase.FOCUS:
            return  # Stop is only valid during focus; ignore otherwise.
        self._phase = Phase.IDLE
        self._started_at = None

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------
    def tick(self) -> None:
        """Advance phase transitions based on elapsed time. Called on each read."""
        if self._started_at is None:
            return

        elapsed = time.monotonic() - self._started_at
        duration = self._current_duration()

        if elapsed < duration:
            return

        # Phase has elapsed.
        if self._phase == Phase.FOCUS:
            # Increment count; 4th pomodoro (count was 3 -> 4) -> long break.
            self._completed_count += 1
            if self._completed_count >= 4:
                self._phase = Phase.LONG_BREAK
            else:
                self._phase = Phase.SHORT_BREAK
            self._started_at = time.monotonic()
        elif self._phase in (Phase.SHORT_BREAK, Phase.LONG_BREAK):
            # Break ended -> idle. Reset count after a long break.
            if self._phase == Phase.LONG_BREAK:
                self._completed_count = 0
            self._phase = Phase.IDLE
            self._started_at = None

    def get_state(self) -> TimerState:
        """Return a snapshot of the timer, computing remaining time on read."""
        self.tick()

        if self._phase == Phase.IDLE or self._started_at is None:
            remaining = 0
        else:
            elapsed = time.monotonic() - self._started_at
            remaining = max(0, int(self._current_duration() - elapsed))

        # Pomodoro number: which pomodoro we're on in the cycle (1..4).
        # During focus, it's the one in progress (completed_count + 1).
        # During break, it's the one just completed (completed_count).
        if self._phase == Phase.FOCUS:
            pomodoro_number = self._completed_count + 1
        elif self._phase in (Phase.SHORT_BREAK, Phase.LONG_BREAK):
            pomodoro_number = self._completed_count
        else:
            pomodoro_number = self._completed_count + 1  # next one to start

        return TimerState(
            phase=self._phase,
            remaining_seconds=remaining,
            completed_count=self._completed_count,
            pomodoro_number=pomodoro_number,
            break_label=BREAK_LABELS.get(self._phase, ""),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _current_duration(self) -> int:
        if self._phase == Phase.FOCUS:
            return FOCUS_SECONDS
        if self._phase == Phase.SHORT_BREAK:
            return SHORT_BREAK_SECONDS
        if self._phase == Phase.LONG_BREAK:
            return LONG_BREAK_SECONDS
        return 0


# Module-level singleton: the single global timer shared by all clients.
timer = PomodoroTimer()
