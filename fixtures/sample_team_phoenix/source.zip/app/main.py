"""FastAPI application for the Pomodoro timer.

Server-authoritative: the in-memory timer singleton is the single source of truth.
The browser polls /timer every second and swaps the rendered fragment.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .timer import Phase, timer

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="Pomodoro")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def _format_mmss(total_seconds: int) -> str:
    minutes, seconds = divmod(total_seconds, 60)
    return f"{minutes:02d}:{seconds:02d}"


def _fragment_name(phase: Phase) -> str:
    if phase == Phase.IDLE:
        return "_idle.html"
    if phase == Phase.FOCUS:
        return "_focus.html"
    return "_break.html"


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> HTMLResponse:
    """Full page with the polling container."""
    state = timer.get_state()
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "state": state,
            "remaining_display": _format_mmss(state.remaining_seconds),
            "fragment": _fragment_name(state.phase),
        },
    )


@app.get("/timer", response_class=HTMLResponse)
async def timer_fragment(request: Request) -> HTMLResponse:
    """Polled every 1s. Returns the phase-specific fragment."""
    state = timer.get_state()
    return templates.TemplateResponse(
        request,
        _fragment_name(state.phase),
        {
            "state": state,
            "remaining_display": _format_mmss(state.remaining_seconds),
        },
    )


@app.post("/start", response_class=HTMLResponse)
async def start(request: Request) -> HTMLResponse:
    """idle -> focus. Returns the focus fragment."""
    timer.start_focus()
    state = timer.get_state()
    return templates.TemplateResponse(
        request,
        _fragment_name(state.phase),
        {
            "state": state,
            "remaining_display": _format_mmss(state.remaining_seconds),
        },
    )


@app.post("/stop", response_class=HTMLResponse)
async def stop(request: Request) -> HTMLResponse:
    """focus -> idle (abandon). Returns the idle fragment."""
    timer.stop_focus()
    state = timer.get_state()
    return templates.TemplateResponse(
        request,
        _fragment_name(state.phase),
        {
            "state": state,
            "remaining_display": _format_mmss(state.remaining_seconds),
        },
    )
